import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./tests/live",
  testMatch: /(design|motion)\.spec\.ts/,
  workers: 1,
  timeout: 60000,
  reporter: [
    ["list"],
    ["json", { outputFile: "artifacts/cinematic-v6/visual-tests.json" }],
  ],
  use: {
    baseURL: "http://localhost:3000",
    viewport: { width: 1440, height: 960 },
    launchOptions: {
      executablePath:
        process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || "/usr/bin/chromium",
    },
    screenshot: "only-on-failure",
  },
  webServer: {
    command: "npm run dev -- --port 3000",
    url: "http://localhost:3000",
    reuseExistingServer: true,
    env: { APP_MODE: "live" },
  },
});
