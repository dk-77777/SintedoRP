# Contrato visual do redesign

Modo público: Persuade. Acesso e áreas internas: Operate.
Execução direta autorizada pelo briefing do usuário; referências fornecidas fixam a direção. Implementação code-led.

## Direction contract
THESIS: Dar rosto ao trabalho doméstico, com abertura editorial e caminhos concretos para trabalhar ou contratar.
OWN-WORLD: Branco mineral, carvão, fotografia P&B e laranja concentrado no símbolo e no acesso. Manrope variável local, botões em cápsula, painéis neutros e imagens com cantos suaves.
STORY: Reconhecer o trabalho, buscar oportunidades e criar uma conta. Mostrar vagas do sistema e mediação sindical existente, sem métricas ou depoimentos inventados.
FIRST VIEWPORT: Navegação horizontal espaçada; título de três linhas à esquerda, corpo curto, CTA e busca funcional. À direita, retrato, detalhe de mãos e bloco preto de apoio sindical. No celular, texto e busca antecedem a imagem.
FORM: Referência 5 para hero; 1 e 2 para acesso; 3 para ritmo; 4 para busca. Seed e0efa63f, atribuição 6. Direção fixada pelo usuário prevalece sobre sorteio. Challengers de costura, autômato e programa monocromático recusados por desviarem das referências. Retidos alinhamento rigoroso, coreografia única e economia de cor.
FINISH: Revisão independente, veredito, DESIGN.md e origem registrada para as imagens.

## Movimento
Revelação das linhas, máscara do retrato e sequência dos elementos. Parallax pequeno somente em desktop; imagem narrativa revelada ao entrar no viewport. Menus e controles respondem às ações. prefers-reduced-motion desativa animações e parallax. Formulários ficam disponíveis imediatamente. Sem biblioteca adicional.

## Invariantes
Preservar backend, APIs, Better Auth, validações, migrações e permissões. Não inserir provedores de login inexistentes. Manter labels, teclado, erros e feedback. As 37 telas de prévia cobrem cinco larguras: 375, 390, 768, 1024 e 1440.
