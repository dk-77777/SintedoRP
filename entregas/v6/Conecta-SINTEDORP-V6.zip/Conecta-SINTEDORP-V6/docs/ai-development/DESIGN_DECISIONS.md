# Direção

Cinematic Human Editorial. Carvão #191817, marrom #31241C, laranja institucional #AF4513, luz #FF743A, marfim #F6EEE5, papel #FCFAF7. Manrope local preservada. Assinatura: fita orgânica SVG em duas curvas entrelaçadas, sem WebGL. Motion editorial intenso apenas na home; estados operacionais discretos.

A V3 usa tokens acinzentados divergentes da paleta documentada. Consolidar valores quentes preservando contraste e cores semânticas. Eliminar refinement-v3.css distribuindo responsabilidades entre home, access e componentes.

## Escolhas implementadas
GSAP + ScrollTrigger foi a única dependência nova. CSS cobre feedback simples; não adicionar Motion/Three.js/Lenis sem necessidade. A fita possui duas curvas com luz e profundidade; a fotografia mantém o papel principal. Sem estatísticas, parceiros ou depoimentos inventados.

O hero usa faixa integral para permitir continuidade tonal com a seção seguinte. Mobile separa fotografia e texto para manter legibilidade. Login/cadastro mantêm seus campos, validações e provedores existentes; a arte é secundária ao formulário.

Crítica visual: retrato original respeitoso, texto com contraste e espaço; fita reduzida para não dominar a foto. Transição clara ao marfim; painéis operacionais mantêm densidade e ação principal evidente. Capturas completas com motion ativo não comprovam reveals fora da viewport — usar reduced-motion para a matriz e vídeo para a coreografia.
