# Manifesto de assets V6

Quatro fotografias ilustrativas geradas com image_gen e inspecionadas visualmente. Pessoas fictícias; não são registros institucionais. A interface informa o caráter ilustrativo. Prompts completos e proveniência acompanham cada WebP em .webp.json.

| Asset | Uso | Tamanho |
|---|---|---|
| public/images/cinematic-v6/hero.webp | Home / hero | 81 KiB |
| public/images/cinematic-v6/login.webp | Login | 91 KiB |
| public/images/cinematic-v6/signup.webp | Cadastro / recuperação | 115 KiB |
| public/images/cinematic-v6/care.webp | Narrativa de cuidado | 159 KiB |

SVG Conecta Flow: src/live/motion/components.tsx, original por código, gradiente independente com IDs únicos, fita/halo/thread separadas. Textura/grid e iluminação são camadas CSS. Fonte Manrope local e licença OFL preservadas. Imagens V3 e escultura legada preservadas para histórico/compatibilidade; não usadas no redesign principal.

Os originais PNG foram gerados em /workspace/generated_images; o pacote distribuído utiliza WebPs otimizados. Não houve recorte artificial de pessoas nem composição de depoimentos.
