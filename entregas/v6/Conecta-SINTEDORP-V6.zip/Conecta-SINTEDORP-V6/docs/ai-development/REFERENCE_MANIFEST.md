# Referências e evidências

| Referência | Material disponível | Uso efetivo |
|---|---|---|
| Banklio | Descrição textual no briefing; imagem ausente | Princípio escuro → marfim com luz intermediária; não reprodução da imagem |
| Salazar | Descrição textual | Escala tipográfica e relação entre headline/forma |
| In Cognita | Descrição textual | Profundidade luminosa e camadas |
| Tony Mak | Descrição textual | Fotografia humana editorial |
| Dark Cinematic Recruitment / se7en / Modern Sign-Up / SaaS Dashboard / The Cape / Maximus Elite | URLs no briefing, não examinadas nesta execução | Nenhuma alegação de inspeção ou cópia |
| Quatro estudos Conecta V6 | HTML e PNGs próprios | Fonte visual direta para implementação |
| Projeto V3 recebido | Código e duas fotografias | Auditoria, captura antes e preservação dos fluxos |

Nenhuma imagem de terceiros foi copiada para publicação. Quatro imagens de pessoas/cuidado foram geradas especificamente para a V6, com prompts e proveniência. Se referências originais forem fornecidas depois, revisitar esta comparação.
