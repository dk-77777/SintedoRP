# Plano V6

0. Auditar ZIP e capturar V3.
1. Estudos renderizáveis: hero, transição, acesso e workspace.
2. Motion modular e assinatura Conecta Flow.
3. Hero com luz, máscaras e transição de scroll nativo.
4. Narrativa, oportunidades e encerramento.
5. Fotografias específicas, otimização e proveniência.
6. Login/cadastro e painéis com dados reais preservados.
7. Typecheck, build, servidor, e2e e matriz visual em cinco larguras.
