# CONECTA SINTEDORP — ULTIMATE CREATIVE ENGINEERING MASTER PROMPT V6

## PREMIUM DIGITAL EXPERIENCE · CINEMATIC MOTION · GENERATIVE ART DIRECTION · INTERACTIVE DEVELOPMENT

---

# 0. SUA MISSÃO

Você está trabalhando LOCALMENTE, por meio do Codex, no repositório existente do Conecta SINTEDORP.

Sua tarefa é elevar drasticamente a qualidade estética e interativa da plataforma, transformando seu visual atual de um portal institucional relativamente estático em uma experiência digital premium, com direção de arte, imagens autorais e animações de alto nível.

O projeto já possui uma base funcional em Next.js, React, TypeScript, PostgreSQL e Better Auth.

Não estamos começando do zero.

Já existe um redesign V3, mas o resultado ainda não atinge o padrão desejado.

Os problemas identificados são:

- Hero ainda pouco cinematográfico.
- Ausência de uma assinatura visual animada.
- Headlines com revelações simples.
- Pouca continuidade entre seções.
- Backgrounds relativamente estáticos.
- Imagens reutilizadas entre diferentes telas.
- Interações pouco expressivas.
- Seções que parecem partes de um portal tradicional.
- Falta de scroll-driven storytelling.
- Pouco aproveitamento da identidade laranja.
- Falta de um Motion Design System completo.
- CSS acumulado ao longo de várias versões de redesign.

**O objetivo não é produzir mais um template moderno.**

Quero que o Conecta SINTEDORP tenha uma experiência própria, reconhecível e memorável.

Você deve atuar como uma equipe formada por:

- Creative Director.
- Senior Art Director.
- UI/UX Design Lead.
- Creative Frontend Engineer.
- Motion Design Engineer.
- 3D/WebGL Artist.
- AI Image Art Director.
- Interaction Designer.
- Performance Engineer.
- Accessibility Engineer.
- QA Automation Engineer.

Quero alto nível de criação e execução, com rigor técnico.

---

# 1. VISÃO CRIATIVA DEFINITIVA

## CONCEITO: CINEMATIC HUMAN EDITORIAL

O Conecta SINTEDORP não deve parecer um banco, uma fintech, uma agência ou um dashboard genérico.

É uma plataforma que conecta trabalhadores domésticos, empregadores e equipe sindical.

A direção visual precisa unir:

**Humanidade + tecnologia + movimento + sofisticação + confiança.**

O resultado deve ter a qualidade estética de sites criativos premiados, mas preservar a utilidade de uma aplicação real.

### Personalidade visual

- Editorial.
- Cinematográfica.
- Contemporânea.
- Humana.
- Tecnológica.
- Sofisticada.
- Acolhedora.
- Marcante.
- Acessível.

Evite linguagem visual corporativa genérica.

Evite excesso de elementos decorativos.

Evite transformar o projeto em uma demonstração aleatória de efeitos.

A experiência deve ser sofisticada porque todos os elementos trabalham juntos.

---

# 2. REFERÊNCIAS VISUAIS — PRIORIDADE MÁXIMA

Crie ou consulte o diretório local:

`design-references/`

O usuário poderá fornecer capturas e imagens nesse diretório.

Inspecione todos os arquivos encontrados.

Não presuma que imagens de outras conversas estejam automaticamente disponíveis no repositório.

Se uma referência essencial ainda não estiver presente, registre a ausência e utilize as fontes disponíveis sem inventar características que não foram verificadas.

## REFERÊNCIA A — BANKLIO

A imagem do Banklio fornecida pelo usuário é uma referência central.

Características desejadas:

- Hero escuro.
- Gradiente atmosférico profundo.
- Grid geométrico sutil.
- Iluminação difusa.
- Transição progressiva de tons escuros para uma superfície clara.
- Elementos visuais integrados ao hero.
- Tipografia grande e refinada.
- Equilíbrio entre conteúdo e imagem.
- Profundidade elegante.
- Continuidade visual entre blocos.

**QUERO ESPECIALMENTE A LÓGICA DO DEGRADÊ DESSA REFERÊNCIA.**

O Sintedo RP deve adaptar essa composição para sua paleta carvão, marfim e laranja.

Não copie as cores verdes ou amarelo-limão do Banklio sem justificativa.

Não copie cartões bancários, métricas ou elementos financeiros.

A referência é de direção de arte e composição.

## REFERÊNCIA B — SALAZAR

Direção de estudo:

- Tipografia gigante.
- Objetos 3D integrados à composição.
- Relação entre texto e geometria.
- Animações que atravessam a headline.
- Movimentos cinematográficos.
- Composição experimental com excelente hierarquia.

Aplicação desejada:

Construir uma experiência na qual o elemento visual autoral do SINTEDORP interaja com a headline e participe da transição para outras seções.

## REFERÊNCIA C — IN COGNITA

Direção de estudo:

- Iluminação atmosférica.
- Sensação espacial.
- Objetos suspensos.
- Gradientes profundos.
- Movimento ambiente.
- Composição imersiva.

Aplicação desejada:

Background vivo com iluminação sutil e profundidade, sem comprometer performance ou legibilidade.

## REFERÊNCIA D — TONY MAK

Direção de estudo:

- Fotografia editorial.
- Iluminação cinematográfica.
- Integração de fotografia e tipografia.
- Contraste entre regiões claras e escuras.
- Composição humana sofisticada.

Aplicação desejada:

Elevar a apresentação das fotografias de profissionais e cenas de cuidado, evitando aparência de publicidade genérica.

## REFERÊNCIA E — DARK CINEMATIC RECRUITMENT

https://dribbble.com/shots/27342620-Dark-Cinematic-Hero-UI-for-AI-Talent-Recruitment-Platform

Estude, se acessível:

- Fotografia dramática.
- Hero de alto contraste.
- Escala tipográfica.
- Apresentação editorial.
- Relação entre uma plataforma de oportunidades e uma estética premium.

Aplicação principal:

Landing page e hero.

## REFERÊNCIA F — SE7EN DESIGN AGENCY

https://dribbble.com/shots/26609244-Design-Agency-Website-se7en

Estude:

- Gradientes laranja.
- Iluminação.
- Composições geométricas.
- Backgrounds com profundidade.
- Elementos gráficos autorais.

Aplicação principal:

Degradês, iluminação, grid de fundo e identidade em movimento.

## REFERÊNCIA G — MODERN SIGN-UP SECTION

https://dribbble.com/shots/26225997-Modern-Sign-Up-Section-UI-Design

Estude:

- Organização dos formulários.
- Tipografia.
- Iluminação.
- Divisão entre arte e conteúdo.
- Hierarquia.
- Estados visuais.

Aplicação principal:

Login e cadastro.

## REFERÊNCIA H — SAAS MARKETING DASHBOARD

https://dribbble.com/shots/27103773-SaaS-Marketing-Dashboard

Estude:

- Hierarquia informacional.
- Composição de cards.
- Uso de espaços.
- Estados.
- Indicadores.
- Consistência de componentes.

Aplicação principal:

Painéis internos do trabalhador, empregador e sindicato.

## REFERÊNCIA I — THE CAPE AGENCY

https://www.awwwards.com/sites/the-cape-agency-2

Estude:

- Tipografia expressiva.
- Contraste cromático.
- Composição de alto impacto.
- Ritmo de seções.
- Transições visuais.

Aplicação principal:

Motion design, transições e tipografia.

## REFERÊNCIA J — MAXIMUS ELITE

https://dribbble.com/shots/27391492-Maximus-Elite-Premium-Hospitality-Recruitment

Estude:

- Fotografia editorial.
- Sofisticação.
- Identidade visual adequada a recrutamento.
- Organização das informações.
- Credibilidade.

Aplicação principal:

Narrativa visual e imagens do Conecta SINTEDORP.

### REGRAS DE UTILIZAÇÃO DAS REFERÊNCIAS

Não misture indiscriminadamente dez estilos visuais.

Extraia de cada referência uma característica específica e construa uma única linguagem coerente.

As imagens locais do usuário terão prioridade sobre referências complementares.

Não copie diretamente marcas, imagens protegidas ou layouts completos de terceiros.

Não utilize imagens de referência no site publicado sem autorização ou licença.

O objetivo é produzir uma implementação original com qualidade comparável.

Se a navegação externa estiver indisponível, utilize as imagens locais e os estudos já documentados. Registre quais referências não puderam ser examinadas.

---

# 3. QUATRO ESTUDOS VISUAIS AUTORAIS OBRIGATÓRIOS

Antes da implementação visual completa, desenvolva quatro estudos de direção de arte específicos para o Conecta SINTEDORP.

Não quero apenas referências de outras empresas.

Quero estudos que mostrem como as referências serão transformadas em uma identidade própria.

## ESTUDO 01 — CINEMATIC HERO

Crie uma composição para a landing page contendo:

- Headline "Quem cuida merece respeito."
- Fundo carvão.
- Iluminação laranja.
- Fotografia editorial.
- Elemento gráfico autoral.
- Profundidade atmosférica.
- Composição assimétrica.
- Botões com identidade premium.
- Espaço negativo intencional.

Planeje também como essa composição poderá ser animada.

## ESTUDO 02 — DARK TO LIGHT TRANSITION

Crie uma composição demonstrando a transição entre:

- Hero escuro.
- Gradiente atmosférico intermediário.
- Superfície clara em marfim.
- Elemento de assinatura atravessando a composição.
- Primeira seção de conteúdo.

Utilize o Banklio como referência principal.

## ESTUDO 03 — PREMIUM AUTHENTICATION

Crie uma direção visual para login e cadastro.

Utilize:

- Formulário extremamente bem organizado.
- Fotografia autoral.
- Composição dividida.
- Iluminação refinada.
- Identidade laranja.
- Microinterações planejadas.
- Excelente responsividade.

Preserve os campos e fluxos reais da aplicação.

## ESTUDO 04 — PREMIUM WORKSPACE

Crie uma proposta visual para os painéis internos.

Inclua:

- Sidebar.
- Indicadores.
- Listas.
- Estados.
- Cards.
- Tabelas.
- Ações principais.
- Navegação.
- Microinterações.

Priorize legibilidade e produtividade.

### ENTREGA DOS ESTUDOS

Salve os estudos em:

`artifacts/creative-direction/`

Sugestão:

- `01-hero-concept.png`
- `02-gradient-transition.png`
- `03-authentication-concept.png`
- `04-workspace-concept.png`

Utilize ferramentas reais de geração de imagens ou renderização quando disponíveis.

Não crie arquivos falsos ou imagens placeholder apenas para preencher a estrutura.

Se não houver geração de imagens disponível, crie estudos renderizáveis por código, com HTML/CSS/SVG, documentando claramente seu status.

Esses estudos não substituem a implementação.

Eles devem orientar o desenvolvimento real.

---

# 4. PALETA DEFINITIVA — ORANGE EDITORIAL

Inspecione primeiro os tokens e documentos atuais.

A direção base desejada inclui:

| Função | Cor |
|---|---|
| Carvão profundo | #191817 |
| Marrom escuro | #31241C |
| Laranja institucional | #AF4513 |
| Laranja luminoso | #FF743A |
| Marfim | #F6EEE5 |
| Off-white | #FCFAF7 |

Essas cores orientam a direção criativa, mas não devem sobrescrever automaticamente os tokens oficiais existentes.

Consolide a paleta após comparar:

- `src/styles/tokens.css`
- `DESIGN.md`
- `docs/PALETA-LARANJA.md`
- Estilos efetivamente utilizados.

## Aplicação

O laranja deve fazer parte da experiência através de:

- CTAs.
- Reveals.
- Assinatura visual.
- Iluminação.
- Hover.
- Indicadores.
- Elementos vetoriais.
- Destaques tipográficos.
- Microinterações.

Não quero apenas botões laranja.

Quero uma identidade reconhecível.

Evite exagerar na saturação ou transformar o site inteiro em laranja.

---

# 5. MOTION DESIGN SYSTEM — FUNDAÇÃO

Atualmente, o projeto possui animações limitadas.

Quero implementar uma arquitetura real de motion design.

Inspecione:

`src/live/motion.ts`

Reestruture gradualmente, conforme necessário.

Considere módulos reutilizáveis em:

`src/live/motion/`

Possíveis responsabilidades:

- Motion tokens.
- Easing.
- Timelines.
- Text reveal.
- Image reveal.
- Scroll scenes.
- Ambient gradients.
- Cursor interactions.
- Motion signature.
- Reduced motion.
- Cleanup.

## TECNOLOGIAS

Priorize:

### GSAP + ScrollTrigger

Para:
- Timelines cinematográficas.
- Máscaras.
- Scroll storytelling.
- Scroll progress.
- Pinned sections.
- Transições coordenadas.

### Motion

Para:
- Microinterações.
- Estados.
- Gestos.
- Transições de componentes.

### SVG

Para:
- Formas autorais.
- Linhas luminosas.
- Máscaras.
- Paths.
- Ilustrações animadas.

### Three.js / React Three Fiber

Somente quando houver justificativa técnica e visual.

### CSS / Web Animations API

Para efeitos leves.

### Lenis

Opcional, apenas se melhorar efetivamente a experiência.

Não instale tudo sem avaliar benefícios.

Não duplique motores para animações simples.

---

# 6. CINEMATIC HERO — RECONSTRUÇÃO

Arquivo principal:

`src/live/home.tsx`

Arquivos de estilos:

`src/styles/home.css`
`src/styles/refinement-v3.css`

O hero deve se tornar a principal demonstração de qualidade visual da plataforma.

## SEQUÊNCIA CINEMATOGRÁFICA

### Cena 1 — Atmosfera

O hero apresenta seu ambiente escuro.

O degradê revela profundidade.

Uma iluminação laranja discreta surge.

O grid de fundo ganha presença progressivamente.

### Cena 2 — Assinatura visual

Uma forma autoral surge no ambiente.

Ela poderá ser uma fita luminosa abstrata, um traço orgânico ou uma estrutura com profundidade.

Não quero uma esfera genérica.

### Cena 3 — Máscara da headline

A headline surge por máscaras tipográficas.

Cada linha deve participar de uma timeline bem coreografada.

Utilize:

- Overflow clipping.
- Transform.
- Stagger.
- Easing.
- GSAP ou equivalente.

Não utilize apenas opacity.

### Cena 4 — Interação entre forma e texto

A forma laranja atravessa ou acompanha parte da composição.

O movimento contribui para revelar a headline.

A máscara e a forma devem estar sincronizadas.

### Cena 5 — Fotografia

A imagem aparece por meio de uma revelação cinematográfica.

Explore:

- Scale.
- Clip-path.
- Iluminação.
- Movimento de câmera simulado.
- Parallax.
- Composição em camadas.

### Cena 6 — Interface

Entram os CTAs, a busca e os elementos auxiliares.

Eles devem aparecer em uma sequência organizada.

A interface precisa ficar utilizável rapidamente.

Não utilize um preloader longo.

---

# 7. SINTEDORP MOTION SIGNATURE

Desenvolva um elemento visual exclusivo.

Nome de trabalho:

**Conecta Flow**

Conceito:

Uma forma luminosa laranja que representa conexão, continuidade, transformação e valorização do trabalho.

Não precisa ser uma linha simples.

Explore:

- Curvas orgânicas.
- SVG paths.
- Materiais translúcidos.
- Luz suave.
- Profundidade.
- Glow.
- Transformações geométricas.
- Composição em camadas.

## A assinatura deve aparecer em momentos estratégicos

No hero:
acompanha a revelação tipográfica.

Na transição:
ajuda a conduzir a transformação entre seções.

Na narrativa:
pode participar da revelação de imagens e títulos.

No final:
retorna de forma transformada.

O objetivo é criar uma identidade visual que o usuário reconheça.

Não precisa permanecer constantemente ativa.

Preserve performance.

---

# 8. DEGRADÊ CINEMATOGRÁFICO BANKLIO-INSPIRED

Quero que o degradê da imagem Banklio seja a principal referência de atmosfera.

## ESTRUTURA

Crie camadas de:

1. Cor base.
2. Gradientes radiais.
3. Iluminação difusa.
4. Textura sutil.
5. Grid discreto.
6. Movimento ambiente.
7. Resposta suave ao cursor.
8. Transições de tonalidade.

O fundo deve apresentar profundidade.

Evite gradientes lineares genéricos.

Evite blur exagerado.

Evite partículas aleatórias.

O resultado deve parecer uma peça de direção de arte.

## TRANSIÇÃO ESCURO → CLARO

A passagem do hero para a próxima seção precisa deixar de ser apenas um retângulo escuro terminando sobre uma página branca.

Quero uma transformação visual contínua.

Durante o scroll:

- O hero reage.
- A iluminação se desloca.
- A fotografia muda suavemente de escala.
- A headline pode sair de cena de maneira coordenada.
- O elemento laranja acompanha o movimento.
- A região escura se transforma em uma superfície clara.
- A próxima seção é revelada.

Essa será uma das experiências mais importantes do projeto.

Não prejudique a rolagem nativa.

Não gere uma transição excessivamente longa.

---

# 9. SCROLL-DRIVEN STORYTELLING

Não quero que a landing page seja apenas uma sequência de containers.

Quero continuidade visual.

## OPORTUNIDADES

Apresente a listagem de vagas com:

- Reveals coordenados.
- Transições sutis.
- Destaques interativos.
- Feedback de hover.
- Indicadores animados.
- Excelente leitura.

Preserve filtros, links, resultados e navegação.

## SEÇÃO DE CUIDADO

Desenvolva uma sequência editorial.

A imagem pode surgir através de uma máscara.

O título aparece progressivamente.

As etapas entram de forma coordenada.

O elemento Conecta Flow pode estabelecer continuidade visual.

## CTA FINAL

Crie um encerramento expressivo.

Utilize:
- Tipografia grande.
- Iluminação controlada.
- Degradê.
- Assinatura visual.
- Movimento.
- Botões refinados.

O final deve parecer a conclusão da narrativa, não apenas outro bloco de interface.

---

# 10. IMAGE REVEALS E TEXT REVEALS

Crie componentes reutilizáveis.

## TextReveal

Variantes:

- Line reveal.
- Word reveal.
- Vertical reveal.
- Horizontal reveal.
- Mask reveal.
- Reveal sincronizado com SVG.

## ImageReveal

Variantes:

- Cortina horizontal.
- Revelação vertical.
- Expansão circular.
- Máscara orgânica.
- Reveal por clip-path.
- Scale reveal.
- Scroll reveal.

## SectionTransition

Permita sincronizar:

- Texto.
- Imagem.
- Background.
- Elementos gráficos.
- Iluminação.

Não aplique o mesmo efeito em todas as seções.

O motion deve variar conforme a narrativa.

---

# 11. GERAÇÃO DE IMAGENS PREMIUM

As imagens atuais do projeto precisam ser reavaliadas.

Arquivos conhecidos:

`public/images/premium-v3/hero.webp`

`public/images/premium-v3/care-detail.webp`

O projeto atualmente reutiliza essas composições em contextos diferentes.

Quero criar uma biblioteca visual mais forte e específica.

## HERO ARTWORK

Produza uma composição original com:

- Fotografia editorial premium.
- Pessoa fictícia representando uma profissional do trabalho doméstico.
- Ambiente arquitetônico sofisticado, mas verossímil.
- Iluminação cinematográfica.
- Expressão natural.
- Composição preparada para headline.
- Tonalidades compatíveis com a identidade.
- Enquadramento responsivo.

Não produzir imagens artificiais estereotipadas, que transformem o trabalho doméstico em fantasia publicitária.

## LOGIN ARTWORK

Crie uma imagem específica para a página de login.

A composição deve transmitir:

- Confiança.
- Acolhimento.
- Identidade.
- Profissionalismo.

## CADASTRO ARTWORK

Crie uma composição diferente, mas coerente com o login.

Não utilize a mesma imagem apenas com outro enquadramento.

## STORYTELLING ASSETS

Crie imagens relacionadas a:

- Trabalho.
- Cuidado.
- Respeito.
- Oportunidade.
- Conexão.
- Acompanhamento.

Não invente parceiros, depoimentos ou métricas.

Não faça imagens fictícias parecerem registros institucionais reais.

## ASSETS ANIMÁVEIS

Sempre que possível, produza:

- Elemento principal separado.
- Background independente.
- Camadas de iluminação.
- SVG.
- Recortes transparentes.
- Máscaras.
- Elementos decorativos reutilizáveis.

Isso permitirá parallax e outras animações com mais qualidade.

## CRITÉRIOS DE ACEITAÇÃO

Uma imagem não estará concluída apenas por ter sido gerada.

Ela precisa:

- Existir fisicamente.
- Estar integrada ao projeto.
- Possuir resolução adequada.
- Estar otimizada.
- Funcionar no layout real.
- Combinar com a paleta.
- Apresentar boa composição no mobile.

Se nenhuma ferramenta real de geração estiver disponível, registre a pendência e utilize recursos construídos por código para os elementos vetoriais e decorativos. Não finja ter gerado uma fotografia.

---

# 12. LOGIN E CADASTRO CINEMATOGRÁFICOS

Arquivos principais:

`src/live/public.tsx`
`src/styles/access.css`

Quero que essas páginas compartilhem a qualidade visual do hero.

Não precisam ter animações tão intensas quanto a landing page.

## LOGIN

Crie:

- Entrada refinada do formulário.
- Revelação mascarada da imagem.
- Iluminação ambiente discreta.
- Microinterações nos campos.
- Transições elegantes.
- Estados de foco.
- Feedback de erro.
- Feedback de sucesso.

## CADASTRO

Crie:

- Artwork específico.
- Coerência cromática.
- Excelente organização dos campos.
- Motion controlado.
- Transições de estado.
- Feedbacks elegantes.

Preserve autenticação, validação e acessibilidade.

Não introduza provedores de login que não existam.

---

# 13. DASHBOARDS PREMIUM

A aplicação possui áreas destinadas a:

- Trabalhadores.
- Empregadores.
- Equipe sindical.

Não quero uma landing page extremamente sofisticada e dashboards abandonados visualmente.

Entretanto, as páginas internas precisam priorizar produtividade.

## MELHORIAS

- Sidebar mais refinada.
- Estados ativos bem definidos.
- Cards organizados.
- Indicadores com hierarquia.
- Skeletons.
- Expansões animadas.
- Feedback nos filtros.
- Transições entre estados.
- Microinterações em tabelas.
- Estados vazios personalizados.
- Feedback visual de ações.

Utilize o estilo de dashboards premium das referências, adaptado à identidade existente.

Não invente gráficos ou indicadores que não correspondam a dados reais.

Não transforme telas operacionais em experiências cinematográficas desnecessárias.

---

# 14. MICROINTERAÇÕES

Crie um sistema consistente para:

## Botões
- Hover.
- Preenchimento.
- Deslocamento de ícone.
- Clique.
- Foco.

## Cards
- Elevação discreta.
- Profundidade.
- Destaque de borda.
- Mudança de iluminação.

## Links
- Underline animado.
- Transição de cor.
- Indicadores direcionais.

## Navbar
- Menu mobile animado.
- Indicador ativo.
- Transição ao navegar.
- Estados de scroll.

## Formulários
- Foco.
- Erro.
- Sucesso.
- Carregamento.

## Imagens
- Reveals.
- Máscaras.
- Transformações controladas.

Todos os movimentos devem seguir o Motion Design System.

Evite efeitos exagerados.

---

# 15. ORGANIZAÇÃO DO CSS

O projeto possui vários arquivos CSS acumulados ao longo de diferentes versões.

Inspecione:

- `globals.css`
- `redesign.css`
- `home.css`
- `access.css`
- `refinement-v3.css`
- `tokens.css`

Identifique:

- Regras duplicadas.
- Overrides.
- Especificidade excessiva.
- Estilos obsoletos.
- Variáveis conflitantes.
- Media queries redundantes.

Refatore gradualmente, preservando os componentes existentes.

Não adicione mais uma enorme camada de overrides sem organização.

Separe estilos de:

- Tokens.
- Componentes.
- Layout.
- Motion.
- Páginas.
- Responsividade.
- Acessibilidade.

---

# 16. RESPONSIVIDADE E ACESSIBILIDADE

Teste:

- 375 px.
- 390 px.
- 768 px.
- 1024 px.
- 1440 px.

No desktop, aproveite a capacidade de interação com cursor.

No mobile, adapte composições e reduza efeitos custosos.

Respeite:

`prefers-reduced-motion`

Não dependa de hover em dispositivos touch.

Não crie conteúdo inacessível quando o JavaScript falhar.

Não remova foco visual.

Não bloqueie o scroll.

Não introduza flashes ou efeitos intensos.

A experiência deve continuar funcional e legível sem animações.

---

# 17. PERFORMANCE

O resultado deve ser visualmente impressionante, mas eficiente.

Priorize:

- Transform.
- Opacity.
- Timelines otimizadas.
- Cleanup de animações.
- Lazy loading.
- Imagens otimizadas.
- Code splitting quando apropriado.
- Fontes eficientes.
- Fallbacks para WebGL.
- Redução de processamento em mobile.

Metas:

- Fluidez próxima de 60 FPS em dispositivos adequados.
- LCP até 2,5 segundos.
- CLS até 0,1.
- INP até 200 ms.
- Boa experiência mobile.

Essas metas precisam ser medidas em ambiente apropriado.

Não invente resultados.

---

# 18. TESTES OBRIGATÓRIOS

Execute, conforme aplicável:

`npm run typecheck`

`npm run build`

`npm run test:server`

`npm run test:live`

`npm run test:e2e`

Acrescente testes apropriados para as novas animações.

Valide:

- Timeline do hero.
- Máscaras tipográficas.
- Transições de scroll.
- Scroll reverso.
- Redução de movimento.
- Resize.
- Navegação entre rotas.
- Mobile.
- Cleanup de timelines.
- Ausência de erros no console.
- Fluxos de login e cadastro.
- Preservação dos links e ações.

Capture screenshots de antes e depois.

Grave a experiência quando houver ferramenta disponível.

Uma imagem estática não comprova uma animação funcional.

Faça uma rodada de crítica visual após cada fase relevante.

Não declare testes executados se não foram realmente realizados.

---

# 19. SISTEMA DE CONTINUIDADE ENTRE CHATS

## OBRIGATÓRIO

Crie:

`docs/ai-development/`

Com os arquivos:

- `MASTER_PLAN.md`
- `PROGRESS.md`
- `DESIGN_DECISIONS.md`
- `MOTION_SPEC.md`
- `ASSET_MANIFEST.md`
- `REFERENCE_MANIFEST.md`
- `CHANGELOG_AI.md`
- `ISSUES_AND_BLOCKERS.md`
- `HANDOFF.md`

## MASTER_PLAN.md

Registre o plano de desenvolvimento completo.

## PROGRESS.md

Registre tarefas:

- Concluídas.
- Em andamento.
- Pendentes.
- Bloqueadas.
- Validadas.

## DESIGN_DECISIONS.md

Registre:

- Paleta.
- Referências.
- Direção de arte.
- Tipografia.
- Composição.
- Decisões visuais.

## MOTION_SPEC.md

Registre cada animação:

- Local.
- Arquivo.
- Técnica.
- Biblioteca.
- Trigger.
- Easing.
- Duração.
- Comportamento mobile.
- Reduced motion.
- Status.

## ASSET_MANIFEST.md

Registre:

- Imagens.
- Caminhos.
- Prompts.
- Origens.
- Versões.
- Onde estão sendo usadas.
- Pendências.

## REFERENCE_MANIFEST.md

Registre todas as referências utilizadas, com origem, arquivos locais e características incorporadas.

## CHANGELOG_AI.md

Registre alterações importantes no código.

## ISSUES_AND_BLOCKERS.md

Registre erros, problemas e limitações.

## HANDOFF.md

Este é o arquivo principal para continuar em outro chat.

Ele deve conter:

1. Resumo do projeto.
2. Estado atual.
3. Fase em andamento.
4. Trabalho concluído.
5. Arquivos modificados.
6. Bibliotecas adicionadas.
7. Animações implementadas.
8. Assets produzidos.
9. Testes realmente executados.
10. Problemas conhecidos.
11. Tarefas pendentes.
12. Próxima ação exata.
13. Como executar o projeto.
14. Prompt de retomada.

---

# 20. REGRA CRÍTICA — QUANDO O CONTEXTO ESTIVER ACABANDO

Quando perceber que a sessão está próxima de encerrar por limite de contexto ou tempo:

**PARE DE INICIAR NOVAS FUNCIONALIDADES.**

Priorize documentar o trabalho.

Não espere consumir todos os tokens.

Se a ferramenta não informar o contexto restante, utilize checkpoints preventivos.

Atualize a documentação:

- No início.
- Após cada fase.
- Depois de alterações importantes.
- Após erros relevantes.
- Antes de grandes tarefas.
- Antes de encerrar.

## PROTOCOLO DE ENCERRAMENTO

1. Pare novas implementações.
2. Salve o estado do código com segurança.
3. Registre o que ficou incompleto.
4. Atualize `PROGRESS.md`.
5. Atualize `MOTION_SPEC.md`.
6. Atualize `ASSET_MANIFEST.md`.
7. Atualize `CHANGELOG_AI.md`.
8. Atualize `ISSUES_AND_BLOCKERS.md`.
9. Atualize `HANDOFF.md`.
10. Escreva a próxima ação exata.
11. Gere um prompt de retomada.
12. Encerre com um resumo ao usuário.

A seção "Próxima ação exata" deve ser extremamente específica.

Exemplo:

"Continuar a implementação da transição do hero para a seção de oportunidades. Abrir os arquivos X e Y, revisar a timeline já implementada, corrigir o problema Z, executar o teste A e comparar as screenshots B e C."

Não escreva apenas "continuar desenvolvimento".

O próximo agente deve conseguir continuar sem precisar reler a conversa anterior.

---

# 21. SEGURANÇA DO REPOSITÓRIO LOCAL

Antes de alterar arquivos:

- Verifique o estado do Git.
- Preserve alterações não commitadas.
- Não sobrescreva trabalho desconhecido.
- Evite operações destrutivas.
- Não publique mudanças automaticamente.
- Não exponha credenciais ou arquivos `.env`.
- Preserve banco, autenticação e APIs.

Trabalhe incrementalmente.

Registre mudanças importantes.

Não faça migração de framework sem necessidade.

---

# 22. ORDEM DE EXECUÇÃO

## FASE 0 — AUDITORIA
- Inspecionar repositório.
- Conferir referências.
- Verificar código atual.
- Criar documentação de continuidade.

## FASE 1 — CREATIVE DIRECTION
- Analisar referências.
- Consolidar identidade.
- Criar quatro estudos visuais autorais.
- Definir Motion Design System.

## FASE 2 — CINEMATIC HERO
- Background.
- Assinatura visual.
- Máscaras tipográficas.
- Timeline.
- Fotografia.
- Interações.

## FASE 3 — DARK TO LIGHT
- Transição escuro-claro.
- ScrollTrigger.
- Continuidade espacial.
- Elemento laranja animado.

## FASE 4 — STORYTELLING
- Seções narrativas.
- Reveals.
- Máscaras.
- Parallax.
- Transições.
- CTA final.

## FASE 5 — ASSETS
- Gerar imagens.
- Melhorar fotografias.
- Produzir composições próprias.
- Integrar e otimizar.

## FASE 6 — PÁGINAS INTERNAS
- Login.
- Cadastro.
- Dashboard.
- Componentes.
- Microinterações.

## FASE 7 — FINALIZAÇÃO
- Consolidar CSS.
- Testar.
- Otimizar.
- Verificar acessibilidade.
- Comparar referências.
- Corrigir problemas.
- Atualizar documentação.

Trabalhe em tarefas pequenas e verificáveis.

Não inicie todas as fases simultaneamente.

Conclua e valide entregas concretas antes de avançar.

---

# 23. REGRAS DE QUALIDADE VISUAL

Não aceite:

- Hero estático.
- Fade-in repetido.
- Gradiente genérico.
- Objeto 3D sem propósito.
- Partículas aleatórias.
- Cursor customizado exagerado.
- Cards repetitivos.
- Layout sem hierarquia.
- Imagens genéricas.
- Formulários sem acabamento.
- Animações desconectadas.
- Excesso de bibliotecas.
- Site pesado e travando.
- Apenas screenshots bonitas sem interatividade real.
- Relatório declarando sucesso sem verificações.

Quero perceber a qualidade tanto na primeira impressão quanto durante a navegação.

---

# 24. CRITÉRIO DEFINITIVO DE SUCESSO

O Conecta SINTEDORP deverá apresentar:

- Hero cinematográfico.
- Tipografia revelada por máscaras.
- Elementos gráficos animados que acompanham a headline.
- Assinatura visual própria.
- Iluminação laranja.
- Background vivo.
- Degradê inspirado no Banklio.
- Transições espaciais.
- Scroll-driven storytelling.
- Imagens premium específicas do projeto.
- Composições em camadas.
- Microinterações refinadas.
- Login e cadastro sofisticados.
- Dashboards coerentes.
- Excelente responsividade.
- Performance.
- Acessibilidade.
- Funcionalidades preservadas.
- Testes reais.
- Documentação completa de continuidade.

**Não quero que o Conecta SINTEDORP pareça um template que recebeu algumas animações.**

Quero que ele pareça uma experiência digital desenvolvida com direção artística, excelente engenharia frontend e atenção obsessiva aos detalhes.

A identidade precisa ser reconhecível.

O movimento precisa ter propósito.

As imagens precisam estar integradas.

A experiência precisa impressionar sem prejudicar o uso real.

---

# 25. INSTRUÇÃO FINAL AO CODEX

Você está autorizado a implementar as melhorias necessárias nos arquivos locais do projeto, respeitando as regras de preservação e segurança estabelecidas acima.

Não fique apenas explicando o que poderia ser feito.

Implemente.

Execute.

Inspecione.

Refine.

Teste.

Documente.

Comece pela auditoria e pela criação dos arquivos de continuidade.

Depois avance para a direção de arte, Motion System, hero cinematográfico e transição escuro-claro.

Utilize as referências com intenção.

Não adicione efeitos aleatórios.

**SE O CONTEXTO ESTIVER ACABANDO, PARE E GERE O HANDOFF COMPLETO DENTRO DO REPOSITÓRIO ANTES DE ENCERRAR.**

O trabalho deve poder continuar em outro chat sem perder as decisões, implementações e tarefas pendentes.

Seu objetivo final é transformar o Conecta SINTEDORP em uma experiência digital premium, original, viva e profissional.