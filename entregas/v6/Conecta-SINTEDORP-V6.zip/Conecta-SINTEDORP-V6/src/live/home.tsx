"use client";
import Image from "next/image";
import Link from "next/link";
import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Icon } from "@/components/icon";
import { useLive } from "./provider";
import { money } from "./ui";
import { useEditorialMotion } from "./motion";
import {
  ConectaFlow,
  TextReveal,
  ImageReveal,
  SectionTransition,
} from "./motion/components";
export function Home() {
  const { state, ready, connectionError } = useLive();
  const router = useRouter();
  const root = useRef<HTMLDivElement>(null);
  const [query, setQuery] = useState("");
  useEditorialMotion(root);
  const jobs =
    state?.jobs.filter((j) => j.status === "Publicada").slice(0, 3) ?? [];
  return (
    <div className="editorial-home" ref={root}>
      <section className="premium-hero" aria-labelledby="home-title">
        <div className="hero-atmosphere" aria-hidden="true">
          <div className="portrait-parallax">
            <Image
              src="/images/cinematic-v6/hero.webp"
              alt=""
              fill
              sizes="(max-width: 767px) 100vw, 80vw"
              preload
            />
          </div>
        </div>
        <div className="hero-light" aria-hidden="true" />
        <div className="hero-grid" aria-hidden="true" />
        <div className="cursor-light" aria-hidden="true" />
        <ConectaFlow className="hero-flow" />
        <div className="hero-copy">
          <p className="hero-kicker">
            <span /> Trabalho com respeito. Conexões com futuro.
          </p>
          <h1 id="home-title" tabIndex={-1}>
            <span className="hero-line">
              <span>Quem cuida</span>
            </span>
            <span className="hero-line">
              <span>merece</span>
            </span>
            <span className="hero-line hero-emphasis">
              <span>respeito.</span>
            </span>
          </h1>
          <p className="hero-description">
            Seu trabalho tem valor. Encontre oportunidades com condições claras
            e o apoio do SINTEDORP.
          </p>
          <div className="hero-actions">
            <Link className="button primary" href="/vagas">
              Encontrar trabalho <Icon name="arrow" size={19} />
            </Link>
            <Link
              className="hero-employer-link"
              href="/cadastro?tipo=empregador"
            >
              Quero contratar <Icon name="arrow" size={17} />
            </Link>
          </div>
          <form
            className="hero-quick-search"
            action="/vagas"
            method="get"
            onSubmit={(e) => {
              e.preventDefault();
              router.push("/vagas?q=" + encodeURIComponent(query.trim()));
            }}
          >
            <label htmlFor="home-query">
              Qual é a sua próxima oportunidade?
            </label>
            <div>
              <Icon name="search" size={20} />
              <input
                id="home-query"
                name="q"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ex.: diarista, babá, cuidador"
              />
              <button type="submit" aria-label="Buscar vagas">
                <Icon name="arrow" size={21} />
              </button>
            </div>
          </form>
        </div>
        <div className="hero-foundation">
          <Link className="hero-support" href="/como-funciona">
            <Icon name="shield" size={24} />
            <span>
              Conexões com apoio sindical<small>Conheça como funciona</small>
            </span>
            <Icon name="arrow" size={20} />
          </Link>
          <span className="hero-location">
            <Icon name="pin" size={16} /> Ribeirão Preto e região
          </span>
        </div>
      </section>
      <SectionTransition />
      <nav
        className="care-categories container"
        aria-label="Encontre vagas por atividade"
      >
        <p>
          Há valor em
          <br />
          <strong>cada cuidado.</strong>
        </p>
        {(
          [
            ["Doméstica", "home"],
            ["Diarista", "leaf"],
            ["Babá", "heart"],
            ["Cuidador de idosos", "user"],
          ] as const
        ).map(([label, icon]) => (
          <Link key={label} href={"/vagas?funcao=" + encodeURIComponent(label)}>
            <Icon name={icon} size={23} />
            <span>{label}</span>
          </Link>
        ))}
      </nav>
      <section
        className="premium-opportunities container"
        aria-labelledby="home-jobs-title"
      >
        <div className="section-heading">
          <div>
            <p className="section-kicker">01 / Oportunidades</p>
            <h2 id="home-jobs-title">
              <TextReveal>Seu próximo passo</TextReveal>
              <TextReveal>pode começar aqui.</TextReveal>
            </h2>
            <p>Explore vagas analisadas pelo sindicato.</p>
          </div>
          <Link className="button secondary" href="/vagas">
            Ver todas as vagas <Icon name="arrow" size={18} />
          </Link>
        </div>
        {jobs.length ? (
          <ul className="opportunity-list">
            {jobs.map((job) => (
              <li key={job.id}>
                <Link href={"/vagas/" + job.id} className="opportunity-row">
                  <span className="opportunity-icon">
                    <Icon
                      name={
                        /Babá|Cuidador/.test(job.category) ? "heart" : "home"
                      }
                      size={23}
                    />
                  </span>
                  <div className="opportunity-description">
                    <span>{job.category}</span>
                    <h3>{job.title}</h3>
                    <p>
                      <Icon name="pin" size={14} />
                      {job.region}
                    </p>
                  </div>
                  <div className="opportunity-schedule">{job.schedule}</div>
                  <div className="opportunity-pay">
                    <strong>{money(job.salary_cents)}</strong>
                    <span>por {job.period.toLowerCase()}</span>
                  </div>
                  <span className="opportunity-arrow">
                    <Icon name="arrow" size={21} />
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <div className="opportunities-empty">
            <span>
              <Icon name="bag" size={30} />
            </span>
            <div>
              <h3>
                {!ready
                  ? "Carregando oportunidades…"
                  : connectionError
                    ? "Oportunidades indisponíveis no momento."
                    : "Novas oportunidades em breve."}
              </h3>
              <p>
                {connectionError
                  ? "Tente atualizar a página em instantes."
                  : "As vagas aparecem aqui depois da análise do sindicato."}
              </p>
              <noscript>
                Ative o JavaScript para consultar as vagas atualizadas.
              </noscript>
            </div>
            <Link href="/cadastro">
              Prepare seu perfil <Icon name="arrow" size={18} />
            </Link>
          </div>
        )}
      </section>
      <section className="care-story container" aria-labelledby="care-title">
        <ImageReveal className="care-story-image">
          <Image
            src="/images/cinematic-v6/care.webp"
            alt="Imagem ilustrativa de mãos dobrando um tecido com cuidado."
            width={1050}
            height={1400}
            sizes="(max-width: 767px) 90vw, 480px"
          />
          <figcaption>O cuidado está nos detalhes.</figcaption>
        </ImageReveal>
        <div className="care-story-copy">
          <p className="section-kicker">02 / O valor de cuidar</p>
          <h2 id="care-title">
            <TextReveal>Cuidar de uma casa</TextReveal>
            <TextReveal>é cuidar de uma vida.</TextReveal>
          </h2>
          <p>
            Aproximamos quem procura trabalho de quem precisa contratar, com
            espaço para diálogo e orientação sindical.
          </p>
          <ol className="care-steps">
            <li>
              <span>01</span>
              <div>
                <h3>Conte com a sua experiência.</h3>
                <p>Crie sua conta e complete seu perfil profissional.</p>
              </div>
            </li>
            <li>
              <span>02</span>
              <div>
                <h3>Encontre uma boa conexão.</h3>
                <p>Conheça as condições da vaga e envie sua candidatura.</p>
              </div>
            </li>
            <li>
              <span>03</span>
              <div>
                <h3>Converse. Combine. Acompanhe.</h3>
                <p>Troque mensagens e registre sua trajetória na plataforma.</p>
              </div>
            </li>
          </ol>
          <Link href="/como-funciona" className="text-link">
            Entenda como funciona <Icon name="arrow" size={18} />
          </Link>
        </div>
      </section>
      <section
        className="connection-invite container"
        aria-labelledby="invite-title"
      >
        <ConectaFlow className="invite-flow" />
        <div>
          <p className="section-kicker">03 / Uma história que continua</p>
          <h2 id="invite-title">
            <TextReveal>Boas relações começam</TextReveal>
            <TextReveal>com respeito.</TextReveal>
          </h2>
          <p>Faça parte dessa conexão.</p>
        </div>
        <div className="invite-actions">
          <Link href="/cadastro" className="button primary">
            Criar minha conta <Icon name="arrow" size={19} />
          </Link>
          <Link href="/contato">Conheça o SINTEDORP</Link>
        </div>
      </section>
      <p className="platform-scope container">
        A plataforma aproxima pessoas. Não garante contratação nem substitui
        obrigações trabalhistas. Imagens ilustrativas criadas para este projeto.
      </p>
    </div>
  );
}
