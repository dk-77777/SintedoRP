"use client";
import { useEffect, type RefObject } from "react";
import { motionTokens } from "./motion/tokens";

/** Lazy loaded choreography. Baseline DOM is always visible without JavaScript. */
export function useEditorialMotion(root: RefObject<HTMLElement | null>) {
  useEffect(() => {
    const element = root.current;
    if (!element) return;
    let disposed = false;
    let cleanup = () => {};
    void Promise.all([import("gsap"), import("gsap/ScrollTrigger")])
      .then(([{ gsap }, { ScrollTrigger }]) => {
        if (disposed) return;
        gsap.registerPlugin(ScrollTrigger);
        const media = gsap.matchMedia();
        media.add(
          {
            motion: "(prefers-reduced-motion: no-preference)",
            desktop: motionTokens.desktop,
          },
          (context) => {
            if (!context.conditions?.motion) return;
            const desktop = context.conditions.desktop;
            const hero = element.querySelector<HTMLElement>(".premium-hero");
            const q = gsap.utils.selector(element);
            if (hero) {
              const enter = gsap.timeline({
                defaults: { ease: motionTokens.ease },
              });
              enter
                .fromTo(
                  q(".hero-light"),
                  { opacity: 0.35 },
                  { opacity: 1, duration: 1.1 },
                  0,
                )
                .fromTo(
                  q(".hero-flow .flow-ribbon, .hero-flow .flow-thread"),
                  { strokeDasharray: 1, strokeDashoffset: 1 },
                  { strokeDashoffset: 0, duration: 1.5, stagger: 0.08 },
                  0.05,
                )
                .fromTo(
                  q(".hero-line > span"),
                  { yPercent: 110, rotate: 2 },
                  {
                    yPercent: 0,
                    rotate: 0,
                    duration: motionTokens.reveal,
                    stagger: motionTokens.stagger,
                  },
                  0.12,
                )
                .fromTo(
                  q(".hero-atmosphere"),
                  { clipPath: "inset(0 0 0 24%)" },
                  { clipPath: "inset(0 0 0 0%)", duration: 1.25 },
                  0.15,
                )
                .fromTo(
                  q(
                    ".hero-kicker, .hero-description, .hero-actions, .hero-quick-search",
                  ),
                  { y: 12 },
                  { y: 0, duration: 0.65, stagger: 0.06 },
                  0.08,
                );
              const scroll = gsap.timeline({
                scrollTrigger: {
                  trigger: hero,
                  start: "top top",
                  end: "bottom top",
                  scrub: 0.65,
                  invalidateOnRefresh: true,
                },
              });
              scroll
                .to(
                  q(".portrait-parallax"),
                  {
                    y: desktop ? 65 : 15,
                    scale: desktop ? 1.08 : 1.025,
                    ease: "none",
                  },
                  0,
                )
                .to(
                  q(".hero-flow"),
                  { y: desktop ? 100 : 25, rotate: -9, ease: "none" },
                  0,
                )
                .to(q(".hero-light"), { yPercent: 15, ease: "none" }, 0);
              if (desktop)
                scroll.to(q(".hero-copy"), { y: -24, ease: "none" }, 0);
              gsap.fromTo(
                q(".transition-flow"),
                { y: -70, rotate: -8 },
                {
                  y: 55,
                  rotate: 7,
                  ease: "none",
                  scrollTrigger: {
                    trigger: ".section-transition",
                    start: "top bottom",
                    end: "bottom top",
                    scrub: 0.8,
                  },
                },
              );
              gsap.fromTo(
                q(".transition-light"),
                { opacity: 0.45, xPercent: -12 },
                {
                  opacity: 1,
                  xPercent: 12,
                  ease: "none",
                  scrollTrigger: {
                    trigger: ".section-transition",
                    start: "top bottom",
                    end: "bottom top",
                    scrub: 0.8,
                  },
                },
              );
            }
            q("[data-reveal]").forEach((node: HTMLElement) => {
              const horizontal = node.dataset.reveal === "horizontal";
              gsap.fromTo(
                node.firstElementChild,
                {
                  yPercent: horizontal ? 0 : 105,
                  xPercent: horizontal ? -12 : 0,
                },
                {
                  yPercent: 0,
                  xPercent: 0,
                  duration: 0.85,
                  ease: motionTokens.ease,
                  scrollTrigger: {
                    trigger: node,
                    start: "top 92%",
                    once: true,
                  },
                },
              );
            });
            q("[data-image-reveal], .motion-panel").forEach(
              (node: HTMLElement) => {
                gsap.fromTo(
                  node,
                  {
                    clipPath:
                      node.dataset.imageReveal === "scale"
                        ? "inset(5% 5% 5% 5%)"
                        : "inset(0 0 85% 0)",
                    scale: 0.98,
                  },
                  {
                    clipPath: "inset(0% 0% 0% 0%)",
                    scale: 1,
                    duration: 1.1,
                    ease: motionTokens.ease,
                    scrollTrigger: {
                      trigger: node,
                      start: "top 88%",
                      once: true,
                    },
                  },
                );
              },
            );
            q(".care-steps li, .opportunity-row, .opportunities-empty").forEach(
              (node: HTMLElement, index: number) => {
                gsap.fromTo(
                  node,
                  { y: 22 },
                  {
                    y: 0,
                    duration: 0.7,
                    delay: (index % 3) * 0.07,
                    ease: motionTokens.ease,
                    scrollTrigger: {
                      trigger: node,
                      start: "top 96%",
                      once: true,
                    },
                  },
                );
              },
            );
            const invite = element.querySelector(".connection-invite");
            if (invite)
              gsap.fromTo(
                q(".invite-flow"),
                { rotate: -12, x: -30 },
                {
                  rotate: 6,
                  x: 30,
                  ease: "none",
                  scrollTrigger: {
                    trigger: invite,
                    start: "top bottom",
                    end: "bottom top",
                    scrub: 1,
                  },
                },
              );
            // Pointer response is limited to capable desktop devices, with no custom cursor.
            let removePointer = () => {};
            if (
              hero &&
              desktop &&
              matchMedia("(hover: hover) and (pointer: fine)").matches
            ) {
              const glow = hero.querySelector(".cursor-light");
              const moveX = gsap.quickTo(glow, "x", {
                duration: 1,
                ease: "power2.out",
              });
              const moveY = gsap.quickTo(glow, "y", {
                duration: 1,
                ease: "power2.out",
              });
              const move = (event: PointerEvent) => {
                const rect = hero.getBoundingClientRect();
                moveX((event.clientX - rect.left - rect.width / 2) * 0.12);
                moveY((event.clientY - rect.top - rect.height / 2) * 0.12);
              };
              const leave = () => {
                moveX(0);
                moveY(0);
              };
              hero.addEventListener("pointermove", move);
              hero.addEventListener("pointerleave", leave);
              removePointer = () => {
                hero.removeEventListener("pointermove", move);
                hero.removeEventListener("pointerleave", leave);
              };
            }
            element.dataset.motionReady = "true";
            return () => {
              removePointer();
              delete element.dataset.motionReady;
            };
          },
          element,
        );
        cleanup = () => media.revert();
      })
      .catch(() => {
        /* The complete static page is the intentional fallback. */
      });
    return () => {
      disposed = true;
      cleanup();
    };
  }, [root]);
}
