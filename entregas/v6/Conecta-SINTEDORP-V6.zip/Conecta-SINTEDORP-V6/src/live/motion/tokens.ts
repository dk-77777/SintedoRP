export const motionTokens = {
  reveal: 0.9,
  stagger: 0.11,
  feedback: 0.18,
  ease: "power3.out",
  reduced: "(prefers-reduced-motion: reduce)",
  desktop: "(min-width: 900px)",
} as const;
