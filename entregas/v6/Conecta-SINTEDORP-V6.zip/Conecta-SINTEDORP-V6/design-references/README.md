# Referências locais
Nenhuma captura de Banklio, Salazar, In Cognita ou Tony Mak veio no ZIP limpo. A direção V6 usa as características descritas pelo usuário e estudos originais em artifacts/creative-direction. Adicione aqui futuras imagens para comparação; não tratar descrições como inspeção visual de um arquivo.
