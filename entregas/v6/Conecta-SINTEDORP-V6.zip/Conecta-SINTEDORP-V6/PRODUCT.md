# Conecta SINTEDORP

<!-- impeccable:product-schema 1 -->

## Platform
web

## Users
Trabalhadores domésticos, empregadores pessoa física ou jurídica e equipe sindical de Ribeirão Preto e região.

## Product Purpose
Conectar quem procura trabalho a quem precisa contratar, com análise de vagas, conversas, histórico e mediação sindical.

## Capabilities and Constraints
Next.js 16.4 / React 19.3, PostgreSQL, Better Auth, e-mail de confirmação obrigatório, sessões reais e permissões no servidor. Cadastro, vagas, candidaturas, mensagens, experiências, avaliações moderadas, atendimento e relatórios. Preservar contratos de API, regras de negócio e autenticação. Desenvolvimento local com dados de teste; publicação institucional e política definitiva pendentes.

## Brand Commitments
Nome Conecta SINTEDORP. Português brasileiro direto e acolhedor. As cinco referências visuais enviadas em 08/10/2026 têm prioridade sobre a identidade anterior. Redesign integral autorizado, incluindo imagens geradas, motion e interfaces operacionais.

## Evidence on Hand
README.md, src/server, src/live e docs descrevem fluxos reais. scripts/preview-data.ts contém exemplos sintéticos para auditoria visual, sem gravação no banco. Não há depoimentos, indicadores de adoção ou parceiros confirmados para publicidade. Imagens geradas são ilustrações editoriais, não registros institucionais.

## Product Principles
- A tarefa principal deve ser compreensível em celular.
- Apresentar condições de trabalho antes da candidatura.
- Permissões e confirmação de identidade não são decisões visuais.
- Não inventar prova social ou funcionalidades.

## Accessibility & Inclusion
Contraste legível, campos com labels, navegação por teclado, alvos de toque confortáveis e redução de movimento. Validar larguras 375, 390, 768, 1024 e 1440 px.
